"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_PICK_CHARS_json"],{

/***/ "./src/presets/sets/PICK_CHARS.json":
/*!******************************************!*\
  !*** ./src/presets/sets/PICK_CHARS.json ***!
  \******************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 12/8","filename":"BC1_Default.json"},{"display":"Default 15/8","filename":"BC1_Default_15_8.json"},{"display":"Default 18/8","filename":"BC1_Default_18_8.json"},{"display":"Default 20/8","filename":"BC1_Default_20_8.json"},{"display":"Familiarity","filename":"BC1_FAM_Spell.json"},{"display":"Recognition","filename":"BC1_Recognition.json"},{"display":"TTR","filename":"BC1_ICR.json"},{"display":"VET","filename":"BC1_VET.json"},{"display":"VST","filename":"BC1_VST.json"},{"display":"Reverse VET","filename":"BC1_RVET.json"},{"display":"Reverse VST","filename":"BC1_RVST.json"},{"display":"Groups of 5","filename":"BC1_Groups_of_5.json"},{"display":"Random groups 1-3","filename":"BC1_Random_groups_1_3.json"},{"display":"Voice On & Spell On","filename":"BC1_Von_Son.json"},{"display":"Voice On & Spell Off","filename":"BC1_Von_Soff.json"},{"display":"OverLearn Letters Flow Rate 1","filename":"POL_17_L.json"},{"display":"Speed Racer Letters Flow Rate 1","filename":"POL_17_L_SR.json"},{"display":"OverLearn Letters Flow Rate 2","filename":"POL_21_L.json"},{"display":"Speed Racer Letters Flow Rate 2","filename":"POL_21_L_SR.json"},{"display":"Progress Evaluation","filename":"BC1_P_Eval.json"}]}');

/***/ })

}]);